# Optibuilds
A web application designed for building optimized pc within customer's price range  using Django Stack

run 'pip install -r requirements.txt' in root directory !

Run 'python manage.py runserver' in root directory

add  your own chromedriver path in executable path  ! 




